public class dice {
    public static boolean compareDie()
    {
        int diceOne = 1 + (int) (Math.random() * 6);
        int diceTwo = 1 + (int) (Math.random() * 6);
        int diceThree = 1 + (int) (Math.random() * 6);
        int diceFour = 1 + (int) (Math.random() * 6);
        int diceFive = 1 + (int) (Math.random() * 6);
        int diceSix = 1 + (int) (Math.random() * 6);
        boolean pairOne = false;
        boolean pairTwo = false;
        boolean pairThree = false;
        if (diceOne == 1 && diceTwo == 1)
        {
            pairOne = true;
        }
        if (diceThree == 1 && diceFour == 1)
        {
            pairTwo = true;
        }
        if (diceFive == 1 && diceSix == 1)
        {
            pairThree = true;
        }
        if (pairOne && pairTwo && pairThree)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static void main(String[] args)
    {
        int oneCount = 0;
        int twoCount = 0;
        int threeCount = 0;
        int fourCount = 0;

        for (int i = 0; i < 100; i++)
        {
            boolean check = compareDie();
            if (check)
            {
                oneCount = oneCount + 1;
            }
        }

        for (int i = 0; i < 1000; i++)
        {
            boolean check = compareDie();
            if (check)
            {
                twoCount = twoCount + 1;
            }
        }

        for (int i = 0; i < 10000; i++)
        {
            boolean check = compareDie();
            if (check)
            {
                threeCount = threeCount + 1;
            }
        }

        for (int i = 0; i < 100000; i++)
        {
            boolean check = compareDie();
            if (check)
            {
                fourCount = fourCount + 1;
            }
        }
        System.out.println("100: " + oneCount + " snake eyes");
        System.out.println("1000: " + twoCount + " snake eyes");
        System.out.println("10000: " + threeCount + " snake eyes");
        System.out.println("100000: " + fourCount + " snake eyes");
    }
}

