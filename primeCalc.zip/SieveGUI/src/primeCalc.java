import javax.swing.*;
import java.awt.event.*;
import java.util.Arrays;

public class primeCalc implements ActionListener {
    JTextField textInput, textOutput;
    JButton calcButton;
    primeCalc() {
        JFrame frame = new JFrame("Prime Calculator");
        JLabel inputLabel = new JLabel("Enter a number!");
        inputLabel.setBounds(20, 20, 360, 30);
        textInput = new JTextField();
        textInput.setBounds(20, 50, 360, 30);
        textInput.setEditable(true);
        textOutput = new JTextField();
        textOutput.setBounds(20, 200, 360, 30);
        textOutput.setEditable(false);
        calcButton = new JButton("Check Primality");
        calcButton.setBounds(20, 100, 160, 30);
        calcButton.addActionListener(this);
        frame.add(inputLabel); frame.add(textInput); frame.add(calcButton);
        frame.add(textOutput);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(400, 300);
        frame.setVisible(true);
    }

    public boolean[] primeArray() {
        int first = 0;
        int second = 0;
        int third = 0;
        int fourth = 0;
        int fifth = 0;
        int sixth = 0;
        int seventh = 0;
        int eighth = 0;
        int ninth = 0;
        int tenth = 0;
        boolean[] sieve = new boolean[1000000];
        Arrays.fill(sieve, true);

        for (int i = 2; i < sieve.length; i++) {
            if (sieve[i]) {
                for (int j = 2 * i; j < sieve.length; j = j + i) {
                    if (j % i == 0 && j != i) {
                        sieve[j] = false;
                    }
                }
            }
        }
        return sieve;
    }
    public void actionPerformed(ActionEvent e) {
        boolean[] primes = primeArray();
        int num = Integer.parseInt(textInput.getText());
        java.lang.String result = Integer.toString(num);
        if(num >= 0 && num < primes.length && primes[num])
        {
            result += " is prime";
        }
        else
        {
            result += " is not prime";
        }
        textOutput.setText(result);
    }

    public static void main(String[] args) {
        new primeCalc();
    }
}
