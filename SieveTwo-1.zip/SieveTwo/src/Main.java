import java.util.Arrays;

public class Main
{
    public static void main(String[] args)
    {
        int first = 0;
        int second = 0;
        int third = 0;
        int fourth = 0;
        int fifth = 0;
        int sixth = 0;
        int seventh = 0;
        int eighth = 0;
        int ninth = 0;
        int tenth = 0;
        boolean[] sieve = new boolean[1000000];
        Arrays.fill(sieve, true);

        for (int i = 2; i < sieve.length; i++)
        {
            if(sieve[i])
            {
                for (int j = 2 * i; j < sieve.length; j = j + i)
                {
                    if(j % i == 0 && j != i)
                    {
                        sieve[j] = false;
                    }
                }
            }
        }
        for (int i = 2; i < sieve.length; i++)
        {
            if (sieve[i])
            {
                if (i <= 99999)
                    first = first + 1;
                else if (i <= 199999)
                    second = second + 1;
                else if (i <= 299999)
                    third = third + 1;
                else if (i <= 399999)
                    fourth = fourth + 1;
                else if (i <= 499999)
                    fifth = fifth + 1;
                else if (i <= 599999)
                    sixth = sixth + 1;
                else if (i <= 699999)
                    seventh = seventh + 1;
                else if (i <= 799999)
                    eighth = eighth + 1;
                else if (i <= 899999)
                    ninth = ninth + 1;
                else
                    tenth = tenth + 1;
            }
        }
        System.out.println("The CS 335 Prime Number Histogram (# of Primes in each interval)");
        System.out.println("2-99,999: " + first);
        System.out.println("100,000-199,999: " + second);
        System.out.println("200,000-299,999: " + third);
        System.out.println("300,000-399,999: " + fourth);
        System.out.println("400,000-499,999: " + fifth);
        System.out.println("500,000-599,999: " + sixth);
        System.out.println("600,000-699,999: " + seventh);
        System.out.println("700,000-799,999: " + eighth);
        System.out.println("800,000-899,999: " + ninth);
        System.out.println("900,000-999,999: " + tenth);
    }
}