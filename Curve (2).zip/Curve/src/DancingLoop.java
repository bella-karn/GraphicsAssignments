import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class DancingLoop extends JFrame
{
    // all of this stuff essentially defines everything I need for my frame so the buttons and slider
    JSlider speed = new JSlider(0, 20, 10);

    AnimCurve curve = new AnimCurve();
    JButton hoop  = new JButton("Hoop");
    JButton points = new JButton("Points");



    public DancingLoop()
    {
        super("Dancing Loop");

        // all of this stuff is essentially just creating the controls for the window, so the slider and the buttons

        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
        JPanel controls = new JPanel();
        add(controls, BorderLayout.NORTH);

        controls.add(hoop);
        controls.add(points);
        controls.add(speed);

        add(curve, BorderLayout.CENTER);

        pack();
        setVisible(true);

        // fixes the buttons so that they work the way they are supposed to.
        hoop.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                curve.showHoop = !curve.showHoop;
            }
        });

        controls.add(hoop);

        points.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                curve.showPoints = !curve.showPoints;
            }
        });

        speed.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                curve.updateSpeed(speed.getValue());
            }
        });

        add(curve, BorderLayout.CENTER);

        pack();
        setVisible(true);
    }

    public class AnimCurve extends JComponent implements Runnable
    {
        // setting up everything I need to so I can use Ball and Bspline correctly
        private int delay=10;
        private static int panelWidth=800;
        private static int panelHeight=800;
        /* points of control structure */
        int xs[] = new int[4],
                ys[] = new int[4];



        Ball balls[] = new Ball[4];

        Bspline[] curves = new Bspline[4];

        boolean showPoints = true;
        boolean showHoop = true;





        public AnimCurve()
        {
            setPreferredSize(new Dimension(800, 800));
            // creates the balls
            for (int i = 0; i < 4; i++) {
                int speed2 = (int) speed.getValue();
                balls[i] = new Ball(panelWidth,panelHeight,
                        (float)(speed2*Math.random()),
                        (float)(speed2*Math.random()),
                        new Color((float)Math.random(), (float)Math.random(), (float)Math.random()));
            }

            // creates the values for the balls, directly pulled from the original dancingLoop
            xs[0] = 50;
            ys[0] = 225;
            xs[1] = 150;
            ys[1] = 125;
            xs[2] = 250;
            ys[2] = 125;
            xs[3] = 350;
            ys[3] = 225;


            resetCurves();
        }

        // updates the speed
        public void updateSpeed(int value) {
            for (int i = 0; i < 4; i++) {
                balls[i].setSpeed(value);
            }
        }

        // sets the curve, almost completely pulled from original dancingCurve
        public void resetCurves(){
            for(int i = 0; i < 4; i++){
                xs[i] = balls[i].getX();
                ys[i] = balls[i].getY();

                curves[i] = new Bspline();

                for(int j = i; j < 4; j++){
                    curves[i].addPoint(xs[j], ys[j]);
                }
                for(int j = 0; j < i; j++){
                    curves[i].addPoint(xs[j], ys[j]);
                }
            }
        }

        // used paint here to make sure things can be seen
        public void paint(Graphics g)
        {

            if(showHoop){
                for(int i = 0; i<4; i++){
                    curves[i].paintCurve(g);
                }
            }

            if(showPoints){
                for (int i = 0; i < 4; i++)
                {
                    balls[i].paintBall(g);
                }
            }
        }



        public void run() {
            try {
                while (true) {
                    resetCurves();
                    for (int i = 0; i < balls.length; i++) {
                        balls[i].moveBall();
                    }

                    java.lang.Thread.sleep(10);
                    repaint();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String argv[]) throws InterruptedException {
        JFrame frame = new JFrame();

        DancingLoop dance = new DancingLoop();
        Thread thread = new Thread(dance.curve);
        thread.start();

        frame.pack();
        frame.setVisible(true);


    }
}

