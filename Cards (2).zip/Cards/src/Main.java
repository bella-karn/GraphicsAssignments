import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import java.util.Arrays;

// Had to look up how to do this so I could set an identifier for the front and back of cards.


public class Main{
    static ImageIcon[] iconsFaceDown;
    static ImageIcon[] iconsFaceUp;
    static boolean[] iconsFace;
    static boolean canClick = true;
    static Timer timer;
    static int matched = 0;
    static int guesses = 0;
    static int clicks = 0;
    static int[] cardNums;
    static Random random = new Random();
    static int cardOneNum = -1;
    static int cardTwoNum = -1;

    static JLabel matchedLabel;
    static JLabel guessesLabel;


    public static void cardNumSet()
    {
        cardNums = new int[52];
        for (int i = 1; i <= 52; i++)
        {
            cardNums[i - 1] = i;
        }
        for (int i = 0; i < 52; i++)
        {
            int randomIndex = random.nextInt(cardNums.length);
            int temp = cardNums[randomIndex];
            cardNums[randomIndex] = cardNums[i];
            cardNums[i] = temp;
        }
    }

    public static ImageIcon[] createIcons()
    {
        String[] imagePathArray = new String[52];

        for (int i = 0; i < 52; i++)
        {
            imagePathArray[i] = ".\\card" + (cardNums[i]) + ".png";
        }
        ImageIcon[] icons = new ImageIcon[imagePathArray.length];
        for(int i = 0; i < imagePathArray.length; i++)
        {
            icons[i] = new ImageIcon(imagePathArray[i]);
        }
        return icons;

    }
    public static ImageIcon createFront()
    {
        String imagePath;
        imagePath = ".\\card53.png";
        ImageIcon back = new ImageIcon(imagePath);
        return back;
    }

    private int extractCardValue(ImageIcon icon) {
        // Your logic to extract the card value from the icon
        // For example, if the icon file name is "card4.png", you can extract the value as follows:
        String fileName = icon.getDescription();
        String[] parts = fileName.split("\\.");
        String[] subparts = parts[0].split("card");
        return Integer.parseInt(subparts[1]);
    }

    // Displays the image. Had to make it a seperate function because I had to call it in the buttons.
    public static void imageDisplay(JPanel panel, ImageIcon[] icons) {
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 13; col++) {
                int buttonIndex = row * 13 + col;
                if (buttonIndex < icons.length) {
                    ImageIcon frontIcon = icons[buttonIndex]; // Use corresponding front icon
                    JButton button = new JButton(frontIcon);
                    int finalRow = row;
                    int finalCol = col;
                    button.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (canClick)
                            {
                                JButton button = (JButton) e.getSource();
                                Icon currentIcon = button.getIcon();
                                int index = Arrays.asList(iconsFaceDown).indexOf(currentIcon);
                                button.setIcon(iconsFaceUp[index]);
                                clicks++;
                                if (cardOneNum == -1)
                                {
                                    cardOneNum = finalRow * 13 + finalCol;
                                }
                                else if (cardTwoNum == -1)
                                {
                                    cardTwoNum = finalRow * 13 + finalCol;
                                    guesses++;
                                    guessesLabel.setText("Guesses: " + guesses);
                                }
                                if (cardTwoNum != -1 && cardNums[cardOneNum] % 13 != cardNums[cardTwoNum] % 13)
                                {
                                    canClick = false;
                                    timer.start();
                                }
                                else if(cardTwoNum != -1 && cardNums[cardOneNum] % 13 == cardNums[cardTwoNum] % 13)
                                {
                                    iconsFace[cardTwoNum] = true;
                                    iconsFace[cardOneNum] = true;
                                    JButton buttonOne = (JButton) panel.getComponent(cardOneNum);
                                    JButton buttonTwo = (JButton) panel.getComponent(cardTwoNum);
                                    buttonOne.setEnabled(false);
                                    buttonTwo.setEnabled(false);
                                    cardOneNum = -1;
                                    cardTwoNum = -1;
                                    matched++;
                                    matchedLabel.setText("Matches: " + matched);
                                }
                            }
                        }
                    });
                    button.setBorderPainted(false);
                    panel.add(button);
                }
            }
        }
    }

    public static void main(String[] args)
    {
        cardNumSet();
        int matches = 0;
        int guesses = 0;
        // creates the frame
        JFrame frame = new JFrame ("Shuffle Cards");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel(new GridLayout(4,13,5,5));

        matchedLabel = new JLabel("Matches: 0");
        guessesLabel = new JLabel("Guesses: 0");

        iconsFaceDown = new ImageIcon[52];
        iconsFace = new boolean[52];
        iconsFaceUp = createIcons();
        for (int i = 0; i < 52; i++)
        {
            iconsFaceDown[i] = createFront();
        }
        for(int i = 0; i < 52; i++)
        {
            iconsFace[i] = false;
        }

        // sets up the grid of buttons
        timer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Collect the indices of flipped cards
                canClick = true;
                java.util.List<Integer> flippedIndices = new ArrayList<>();
                for (int i = 0; i < iconsFace.length; i++) {
                    if (!iconsFace[i]) {
                        flippedIndices.add(i);
                    }
                }
                // Flip back all flipped cards
                for (int index : flippedIndices) {

                    JButton button = (JButton) panel.getComponent(index);

                    button.setIcon(iconsFaceDown[index]);
                    button.setEnabled(true);
                }
                // Reset the timer
                cardOneNum = -1;
                cardTwoNum = -1;
                timer.stop();
            }
        });
        imageDisplay(panel, iconsFaceDown);

        frame.getContentPane().add(BorderLayout.CENTER, panel);

        // implements the reset button
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                ImageIcon[] iconsTwo = createIcons();
                panel.removeAll();
                imageDisplay(panel, iconsFaceDown);
                panel.revalidate();
                panel.repaint();
            }
        });
        // implements the quit button
        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
        // actually puts the button on the bottom of the panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(matchedLabel);
        bottomPanel.add(guessesLabel);
        bottomPanel.add(resetButton);
        bottomPanel.add(quitButton);

        frame.getContentPane().add(BorderLayout.SOUTH, bottomPanel);

        frame.setSize(1000, 550);
        frame.setVisible(true);
    }

}