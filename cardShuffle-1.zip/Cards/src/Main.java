import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Arrays;

public class Main implements ActionListener {
    // creates the array of icon images to be implemented later
    public static ImageIcon[] createIcons()
    {
        String[] imagePathArray = new String[52];

        for (int i = 0; i < 52; i++)
        {
            imagePathArray[i] = ".\\card" + (i+1) + ".png";
        }
        ImageIcon[] icons = new ImageIcon[imagePathArray.length];
        for(int i = 0; i < imagePathArray.length; i++)
        {
            icons[i] = new ImageIcon(imagePathArray[i]);
        }
        return icons;

    }

    // Displays the image. Had to make it a seperate function because I had to call it in the buttons.
    public static void imageDisplay(ImageIcon[] icons, JPanel panel)
    {
        for (int row = 0; row < 4; row++)
        {
            for (int col = 0; col < 13; col++)
            {
                int buttonIndex = row * 13 + col;
                if (buttonIndex < icons.length)
                {
                    JButton button = new JButton(icons[buttonIndex]);
                    button.addActionListener(new Main());
                    button.setBorderPainted(false);
                    panel.add(button);
                }
            }
        }
    }

    public static void main(String[] args)
    {
        // creates the frame
        JFrame frame = new JFrame ("Shuffle Cards");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel(new GridLayout(4,13,5,5));

        ImageIcon[] icons = createIcons();
        // sets up the grid of buttons
        imageDisplay(icons, panel);

        frame.getContentPane().add(BorderLayout.CENTER, panel);

        // implements the shuffle button
        JButton shuffleButton = new JButton("Shuffle");
        shuffleButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Random random = new Random();
                // This was the best way I knew to "sort" it? I know it isn't sorting but swapping everything around
                for (int i = 0; i < icons.length; i++)
                {
                    int randomIndex = random.nextInt(icons.length);
                    ImageIcon temp = icons[randomIndex];
                    icons[randomIndex] = icons[i];
                    icons[i] = temp;
                }
                panel.removeAll();
                imageDisplay(icons, panel);
                panel.revalidate();
                panel.repaint();
            }
        });
        // implements the reset button
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                ImageIcon[] iconsTwo = createIcons();
                panel.removeAll();
                imageDisplay(iconsTwo, panel);
                panel.revalidate();
                panel.repaint();
            }
        });
        // implements the quit button
        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
        // actually puts the button on the bottom of the panel
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(shuffleButton);
        bottomPanel.add(resetButton);
        bottomPanel.add(quitButton);

        frame.getContentPane().add(BorderLayout.SOUTH, bottomPanel);

        frame.setSize(1000, 550);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {
        System.out.println("Button clicked");
    }
}